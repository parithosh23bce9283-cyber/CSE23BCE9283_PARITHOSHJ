<h1 align="center">🎓 College Management System</h1>

<p align="center">
  <img src="https://img.shields.io/badge/Java-17-007396?style=for-the-badge&logo=java&logoColor=white" />
  <img src="https://img.shields.io/badge/Spring%20Boot-3.2.5-6DB33F?style=for-the-badge&logo=springboot&logoColor=white" />
  <img src="https://img.shields.io/badge/MongoDB-7.0-47A248?style=for-the-badge&logo=mongodb&logoColor=white" />
  <img src="https://img.shields.io/badge/Spring%20Security-JWT-6DB33F?style=for-the-badge&logo=springsecurity&logoColor=white" />
  <img src="https://img.shields.io/badge/Maven-3.9-C71A36?style=for-the-badge&logo=apachemaven&logoColor=white" />
</p>

<p align="center">
  A production-ready, secure RESTful API backend for managing all core college operations — built with <strong>Spring Boot 3.x</strong>, <strong>MongoDB</strong>, and <strong>JWT Authentication</strong>.
</p>

---

## 📋 Table of Contents

- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [Getting Started](#-getting-started)
- [API Endpoints](#-api-endpoints)
- [Security](#-security)
- [Configuration](#-configuration)
- [Contributing](#-contributing)

---

## ✨ Features

- 🔐 **JWT-based Authentication & Authorization** — Secure role-based access control
- 🏛️ **Department Management** — Create and manage college departments
- 👨‍🏫 **Faculty Management** — Full CRUD for faculty records with department association
- 👨‍🎓 **Student Management** — Student registration, profiles, and enrollment tracking
- 📚 **Course Management** — Course creation linked to departments and faculty
- 📝 **Enrollment System** — Enroll students in courses with validation
- 📊 **Attendance Tracking** — Record and query attendance per student per course
- 🎯 **Exam & Results Management** — Record exam scores with automatic GPA calculation
- 🆔 **Auto-generated IDs** — Human-readable, prefixed IDs (e.g., `STU001`, `FAC001`)

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 17 |
| Framework | Spring Boot 3.2.5 |
| Database | MongoDB 7.0 |
| Security | Spring Security + JJWT 0.11.5 |
| Validation | Jakarta Bean Validation |
| Build Tool | Apache Maven |
| Boilerplate | Lombok |

---

## 📁 Project Structure

```
college-management-system/
├── src/
│   └── main/
│       ├── java/com/college/
│       │   ├── CollegeManagementSystemApplication.java
│       │   ├── config/          # Security & CORS configuration
│       │   ├── controller/      # REST API controllers
│       │   │   ├── AuthController.java
│       │   │   ├── DepartmentController.java
│       │   │   ├── FacultyController.java
│       │   │   ├── StudentController.java
│       │   │   ├── CourseController.java
│       │   │   ├── EnrollmentController.java
│       │   │   ├── AttendanceController.java
│       │   │   └── ExamController.java
│       │   ├── dto/             # Request & Response DTOs
│       │   │   ├── request/
│       │   │   └── response/
│       │   ├── exception/       # Global exception handling
│       │   ├── model/           # MongoDB document models
│       │   │   ├── Department.java
│       │   │   ├── Faculty.java
│       │   │   ├── Student.java
│       │   │   ├── Course.java
│       │   │   ├── Enrollment.java
│       │   │   ├── Attendance.java
│       │   │   ├── Exam.java
│       │   │   └── User.java
│       │   ├── repository/      # Spring Data MongoDB repositories
│       │   ├── security/        # JWT utilities & filters
│       │   └── service/         # Business logic layer
│       └── resources/
│           └── application.properties
└── pom.xml
```

---

## 🚀 Getting Started

### Prerequisites

Ensure you have the following installed:

- [Java 17+](https://adoptium.net/)
- [Apache Maven 3.9+](https://maven.apache.org/)
- [MongoDB 7.0+](https://www.mongodb.com/try/download/community) running on `localhost:27017`

### 1. Clone the Repository

```bash
git clone https://github.com/akhilkumar-dot/college-management-system.git
cd college-management-system
```

### 2. Configure the Application

Open `src/main/resources/application.properties` and set your credentials:

```properties
# MongoDB
spring.data.mongodb.uri=mongodb://localhost:27017/college_db

# JWT Secret (use a strong, unique key in production)
jwt.secret=yourSuperSecretKey
jwt.expiration=86400000
```

> ⚠️ **Never commit real secrets to version control.** Use environment variables or a secrets manager in production.

### 3. Build & Run

```bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

The server starts on **`http://localhost:8080`**

---

## 📡 API Endpoints

### 🔑 Authentication

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/auth/register` | Register a new user | Public |
| `POST` | `/api/auth/login` | Login & receive JWT token | Public |

### 🏛️ Departments

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/departments` | Create department | Admin |
| `GET` | `/api/departments` | List all departments | Authenticated |
| `GET` | `/api/departments/{id}` | Get department by ID | Authenticated |
| `PUT` | `/api/departments/{id}` | Update department | Admin |
| `DELETE` | `/api/departments/{id}` | Delete department | Admin |

### 👨‍🏫 Faculty

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/faculty` | Add faculty member | Admin |
| `GET` | `/api/faculty` | List all faculty | Authenticated |
| `GET` | `/api/faculty/{id}` | Get faculty by ID | Authenticated |
| `PUT` | `/api/faculty/{id}` | Update faculty | Admin |
| `DELETE` | `/api/faculty/{id}` | Delete faculty | Admin |

### 👨‍🎓 Students

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/students` | Register student | Admin |
| `GET` | `/api/students` | List all students | Authenticated |
| `GET` | `/api/students/{id}` | Get student by ID | Authenticated |
| `PUT` | `/api/students/{id}` | Update student | Admin |
| `DELETE` | `/api/students/{id}` | Delete student | Admin |

### 📚 Courses

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/courses` | Create course | Admin |
| `GET` | `/api/courses` | List all courses | Authenticated |
| `GET` | `/api/courses/{id}` | Get course by ID | Authenticated |
| `PUT` | `/api/courses/{id}` | Update course | Admin |
| `DELETE` | `/api/courses/{id}` | Delete course | Admin |

### 📝 Enrollments

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/enrollments` | Enroll student in course | Admin |
| `GET` | `/api/enrollments` | List all enrollments | Authenticated |
| `GET` | `/api/enrollments/student/{studentId}` | Enrollments by student | Authenticated |
| `DELETE` | `/api/enrollments/{id}` | Cancel enrollment | Admin |

### 📊 Attendance

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/attendance` | Mark attendance | Admin/Faculty |
| `GET` | `/api/attendance/student/{studentId}` | Get attendance by student | Authenticated |
| `GET` | `/api/attendance/course/{courseId}` | Get attendance by course | Authenticated |

### 🎯 Exams & Results

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| `POST` | `/api/exams` | Record exam result | Admin |
| `GET` | `/api/exams/student/{studentId}` | Results by student | Authenticated |
| `GET` | `/api/exams/course/{courseId}` | Results by course | Authenticated |

---

## 🔒 Security

This API uses **JWT (JSON Web Token)** for stateless authentication:

1. Register or Login to receive a Bearer token
2. Include the token in the `Authorization` header for all protected routes:

```http
Authorization: Bearer <your_jwt_token>
```

Token expiry defaults to **24 hours** (`86400000` ms).

---

## ⚙️ Configuration

| Property | Default | Description |
|---|---|---|
| `server.port` | `8080` | Application port |
| `spring.data.mongodb.uri` | `localhost:27017/college_db` | MongoDB connection URI |
| `jwt.secret` | *(set your own)* | JWT signing secret |
| `jwt.expiration` | `86400000` | Token TTL in milliseconds |

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Commit your changes: `git commit -m 'feat: add your feature'`
4. Push to the branch: `git push origin feature/your-feature-name`
5. Open a Pull Request

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

<p align="center">Built with ❤️ using Spring Boot & MongoDB</p>
