package com.college.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * Request body for recording an exam result.
 */
@Data
public class ExamRequest {

    @NotBlank(message = "Student ID is required")
    private String studentId;

    @NotBlank(message = "Course ID is required")
    private String courseId;

    @NotBlank(message = "Exam type is required")
    @Pattern(regexp = "INTERNAL|MIDTERM|FINAL",
             message = "Exam type must be INTERNAL, MIDTERM, or FINAL")
    private String examType;

    @Min(value = 1, message = "Total marks must be at least 1")
    private int totalMarks;

    @Min(value = 0, message = "Obtained marks cannot be negative")
    private int obtainedMarks;

    @Min(value = 1, message = "Semester must be between 1 and 8")
    @Max(value = 8, message = "Semester must be between 1 and 8")
    private int semester;

    @NotBlank(message = "Exam date is required (format: yyyy-MM-dd)")
    private String examDate;
}
