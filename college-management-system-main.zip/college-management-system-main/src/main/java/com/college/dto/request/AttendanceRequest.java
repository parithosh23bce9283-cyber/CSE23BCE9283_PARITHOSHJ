package com.college.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * Request body for marking attendance.
 */
@Data
public class AttendanceRequest {

    @NotBlank(message = "Student ID is required")
    private String studentId;

    @NotBlank(message = "Course ID is required")
    private String courseId;

    @NotBlank(message = "Date is required (format: yyyy-MM-dd)")
    private String date;

    @NotBlank(message = "Status is required")
    @Pattern(regexp = "PRESENT|ABSENT|LATE",
             message = "Status must be PRESENT, ABSENT, or LATE")
    private String status;

    @NotBlank(message = "Marker faculty ID is required")
    private String markedBy;
}
