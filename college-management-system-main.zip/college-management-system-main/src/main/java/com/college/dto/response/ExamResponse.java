package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExamResponse {

    private String id;
    private String studentId;
    private String studentName;
    private String rollNumber;
    private String courseId;
    private String courseName;
    private String courseCode;
    private String examType;
    private int totalMarks;
    private int obtainedMarks;
    private String grade;
    private double percentage;
    private int semester;
    private String examDate;
    private LocalDateTime createdAt;
}
