package com.college.dto.response;

import lombok.*;

/**
 * Returned on successful login/register containing the JWT token.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {

    private String token;
    private String tokenType;
    private String username;
    private String email;
    private String role;
    private long expiresIn; // milliseconds
}
