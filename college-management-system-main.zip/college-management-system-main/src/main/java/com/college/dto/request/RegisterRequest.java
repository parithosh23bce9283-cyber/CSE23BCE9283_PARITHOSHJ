package com.college.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * Request body for user registration.
 */
@Data
public class RegisterRequest {

    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    // Must be one of: ADMIN, FACULTY, STUDENT
    @NotBlank(message = "Role is required")
    @Pattern(regexp = "ADMIN|FACULTY|STUDENT", message = "Role must be ADMIN, FACULTY, or STUDENT")
    private String role;
}
