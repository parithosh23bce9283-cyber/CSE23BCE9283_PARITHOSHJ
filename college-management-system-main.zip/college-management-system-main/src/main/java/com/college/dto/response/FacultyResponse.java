package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FacultyResponse {

    private String id;
    private String name;
    private String email;
    private String phone;
    private String employeeId;
    private String departmentId;
    private String departmentName;
    private String designation;
    private String qualification;
    private int experience;
    private boolean isActive;
    private LocalDateTime createdAt;
}
