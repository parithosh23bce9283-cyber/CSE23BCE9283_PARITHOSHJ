package com.college.dto.response;

import lombok.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CourseResponse {

    private String id;
    private String name;
    private String courseCode;
    private String departmentId;
    private String departmentName;
    private String facultyId;
    private String facultyName;
    private int credits;
    private int semester;
    private int maxStudents;
    private int enrolledStudents;
    private LocalDateTime createdAt;
}
