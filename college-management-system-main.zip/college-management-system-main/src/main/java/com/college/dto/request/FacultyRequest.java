package com.college.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * Request body for creating/updating a faculty member.
 */
@Data
public class FacultyRequest {

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone is required")
    private String phone;

    @NotBlank(message = "Department ID is required")
    private String departmentId;

    // ASSISTANT_PROFESSOR / ASSOCIATE_PROFESSOR / PROFESSOR
    @NotBlank(message = "Designation is required")
    @Pattern(regexp = "ASSISTANT_PROFESSOR|ASSOCIATE_PROFESSOR|PROFESSOR",
             message = "Designation must be ASSISTANT_PROFESSOR, ASSOCIATE_PROFESSOR, or PROFESSOR")
    private String designation;

    @NotBlank(message = "Qualification is required")
    private String qualification;

    @Min(value = 0, message = "Experience cannot be negative")
    private int experience;
}
