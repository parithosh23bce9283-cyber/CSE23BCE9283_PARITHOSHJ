package com.college.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * Request body for creating/updating a course.
 */
@Data
public class CourseRequest {

    @NotBlank(message = "Course name is required")
    private String name;

    @NotBlank(message = "Course code is required")
    private String courseCode; // e.g. CS101

    @NotBlank(message = "Department ID is required")
    private String departmentId;

    @NotBlank(message = "Faculty ID is required")
    private String facultyId;

    @Min(value = 1, message = "Credits must be at least 1")
    private int credits;

    @Min(value = 1, message = "Semester must be between 1 and 8")
    @Max(value = 8, message = "Semester must be between 1 and 8")
    private int semester;

    @Min(value = 1, message = "Max students must be at least 1")
    private int maxStudents;
}
