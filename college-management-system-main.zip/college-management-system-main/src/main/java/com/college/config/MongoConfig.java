package com.college.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * MongoDB configuration.
 * Enables auditing (createdAt/updatedAt auto-population if needed)
 * and scans repository interfaces.
 */
@Configuration
@EnableMongoAuditing
@EnableMongoRepositories(basePackages = "com.college.repository")
public class MongoConfig {
    // Spring Boot auto-configures the MongoClient from application.properties.
    // This class exists for potential future customization (e.g., converters).
}
