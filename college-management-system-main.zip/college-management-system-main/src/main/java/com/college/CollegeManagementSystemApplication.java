package com.college;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main entry point for the College Management System.
 * Bootstraps the Spring Boot application with auto-configuration.
 */
@SpringBootApplication
public class CollegeManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollegeManagementSystemApplication.class, args);
        System.out.println("===========================================");
        System.out.println("  College Management System is Running!   ");
        System.out.println("  Port: 8080 | DB: college_db (MongoDB)   ");
        System.out.println("===========================================");
    }
}
