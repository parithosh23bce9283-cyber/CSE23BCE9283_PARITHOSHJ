package com.college.repository;

import com.college.model.Faculty;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FacultyRepository extends MongoRepository<Faculty, String> {

    boolean existsByEmail(String email);

    boolean existsByEmployeeId(String employeeId);

    Optional<Faculty> findByEmail(String email);

    List<Faculty> findByDepartmentId(String departmentId);

    long countByEmployeeIdStartingWith(String prefix);
}
