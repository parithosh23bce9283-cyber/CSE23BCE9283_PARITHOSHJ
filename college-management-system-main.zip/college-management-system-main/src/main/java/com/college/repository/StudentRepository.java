package com.college.repository;

import com.college.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends MongoRepository<Student, String> {

    boolean existsByEmail(String email);

    boolean existsByRollNumber(String rollNumber);

    Optional<Student> findByEmail(String email);

    Optional<Student> findByRollNumber(String rollNumber);

    List<Student> findByDepartmentId(String departmentId);

    Page<Student> findAll(Pageable pageable);

    // Case-insensitive search by name OR roll number using MongoDB regex
    @Query("{ '$or': [ { 'name': { '$regex': ?0, '$options': 'i' } }, { 'rollNumber': { '$regex': ?1, '$options': 'i' } } ] }")
    List<Student> searchByNameOrRollNumber(String name, String rollNumber);

    long countByRollNumberStartingWith(String prefix);
}
