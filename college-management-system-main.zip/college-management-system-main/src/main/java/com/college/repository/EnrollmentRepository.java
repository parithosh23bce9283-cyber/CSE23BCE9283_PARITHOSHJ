package com.college.repository;

import com.college.model.Enrollment;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EnrollmentRepository extends MongoRepository<Enrollment, String> {

    List<Enrollment> findByStudentId(String studentId);

    List<Enrollment> findByCourseId(String courseId);

    // Check for duplicate active enrollment
    Optional<Enrollment> findByStudentIdAndCourseIdAndStatus(
            String studentId, String courseId, String status);

    boolean existsByStudentIdAndCourseIdAndStatus(
            String studentId, String courseId, String status);
}
