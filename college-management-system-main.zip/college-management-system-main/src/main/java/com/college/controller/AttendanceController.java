package com.college.controller;

import com.college.dto.request.AttendanceRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.AttendanceResponse;
import com.college.service.AttendanceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Attendance marking and reporting endpoints.
 */
@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    @Autowired
    private AttendanceService attendanceService;

    /** POST /api/attendance */
    @PostMapping
    public ResponseEntity<ApiResponse<AttendanceResponse>> mark(
            @Valid @RequestBody AttendanceRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Attendance marked",
                        attendanceService.mark(request)));
    }

    /** GET /api/attendance/course/{courseId} */
    @GetMapping("/course/{courseId}")
    public ResponseEntity<ApiResponse<List<AttendanceResponse>>> getByCourse(
            @PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.success("Attendance fetched",
                attendanceService.getByCourse(courseId)));
    }

    /** GET /api/attendance/student/{studentId} */
    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<List<AttendanceResponse>>> getByStudent(
            @PathVariable String studentId) {
        return ResponseEntity.ok(ApiResponse.success("Attendance fetched",
                attendanceService.getByStudent(studentId)));
    }

    /**
     * GET /api/attendance/student/{studentId}/percentage
     * Returns attendance % per course and flags if below 75%.
     */
    @GetMapping("/student/{studentId}/percentage")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getPercentage(
            @PathVariable String studentId) {
        return ResponseEntity.ok(ApiResponse.success("Attendance percentage calculated",
                attendanceService.getAttendancePercentage(studentId)));
    }

    /** GET /api/attendance/course/{courseId}/date/{date} */
    @GetMapping("/course/{courseId}/date/{date}")
    public ResponseEntity<ApiResponse<List<AttendanceResponse>>> getByDate(
            @PathVariable String courseId,
            @PathVariable String date) {
        return ResponseEntity.ok(ApiResponse.success("Attendance fetched",
                attendanceService.getByCourseAndDate(courseId, date)));
    }
}
