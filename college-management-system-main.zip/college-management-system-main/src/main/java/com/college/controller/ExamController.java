package com.college.controller;

import com.college.dto.request.ExamRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.ExamResponse;
import com.college.service.ExamService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Exam results endpoints with GPA calculation.
 */
@RestController
@RequestMapping("/api/exams")
public class ExamController {

    @Autowired
    private ExamService examService;

    /** POST /api/exams */
    @PostMapping
    public ResponseEntity<ApiResponse<ExamResponse>> addResult(
            @Valid @RequestBody ExamRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Exam result added",
                        examService.addResult(request)));
    }

    /** GET /api/exams/student/{studentId} */
    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<List<ExamResponse>>> getByStudent(
            @PathVariable String studentId) {
        return ResponseEntity.ok(ApiResponse.success("Exam results fetched",
                examService.getByStudent(studentId)));
    }

    /** GET /api/exams/course/{courseId} */
    @GetMapping("/course/{courseId}")
    public ResponseEntity<ApiResponse<List<ExamResponse>>> getByCourse(
            @PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.success("Exam results fetched",
                examService.getByCourse(courseId)));
    }

    /**
     * GET /api/exams/student/{studentId}/gpa
     * Calculates GPA using FINAL exam results weighted by course credits.
     */
    @GetMapping("/student/{studentId}/gpa")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getGpa(
            @PathVariable String studentId) {
        return ResponseEntity.ok(ApiResponse.success("GPA calculated",
                examService.calculateGpa(studentId)));
    }

    /** PUT /api/exams/{id} */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ExamResponse>> update(
            @PathVariable String id,
            @Valid @RequestBody ExamRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Exam result updated",
                examService.update(id, request)));
    }
}
