package com.college.controller;

import com.college.dto.request.CourseRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.CourseResponse;
import com.college.service.CourseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Course management endpoints.
 */
@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    /** POST /api/courses */
    @PostMapping
    public ResponseEntity<ApiResponse<CourseResponse>> create(
            @Valid @RequestBody CourseRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Course created",
                        courseService.create(request)));
    }

    /** GET /api/courses */
    @GetMapping
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Courses fetched", courseService.getAll()));
    }

    /** GET /api/courses/{id} */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CourseResponse>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Course found", courseService.getById(id)));
    }

    /** GET /api/courses/department/{departmentId} */
    @GetMapping("/department/{departmentId}")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getByDepartment(
            @PathVariable String departmentId) {
        return ResponseEntity.ok(ApiResponse.success("Courses fetched",
                courseService.getByDepartment(departmentId)));
    }

    /** GET /api/courses/faculty/{facultyId} */
    @GetMapping("/faculty/{facultyId}")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getByFaculty(
            @PathVariable String facultyId) {
        return ResponseEntity.ok(ApiResponse.success("Courses fetched",
                courseService.getByFaculty(facultyId)));
    }

    /** PUT /api/courses/{id} */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<CourseResponse>> update(
            @PathVariable String id,
            @Valid @RequestBody CourseRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Course updated",
                courseService.update(id, request)));
    }

    /** DELETE /api/courses/{id} */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable String id) {
        courseService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Course deleted", null));
    }
}
