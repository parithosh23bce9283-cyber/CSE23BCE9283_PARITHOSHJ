package com.college.controller;

import com.college.dto.request.EnrollmentRequest;
import com.college.dto.response.ApiResponse;
import com.college.dto.response.EnrollmentResponse;
import com.college.service.EnrollmentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Enrollment endpoints — enroll, drop, complete a student-course relation.
 */
@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {

    @Autowired
    private EnrollmentService enrollmentService;

    /** POST /api/enrollments */
    @PostMapping
    public ResponseEntity<ApiResponse<EnrollmentResponse>> enroll(
            @Valid @RequestBody EnrollmentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Student enrolled successfully",
                        enrollmentService.enroll(request)));
    }

    /** GET /api/enrollments */
    @GetMapping
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success("Enrollments fetched",
                enrollmentService.getAll()));
    }

    /** GET /api/enrollments/student/{studentId} */
    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByStudent(
            @PathVariable String studentId) {
        return ResponseEntity.ok(ApiResponse.success("Enrollments fetched",
                enrollmentService.getByStudent(studentId)));
    }

    /** GET /api/enrollments/course/{courseId} */
    @GetMapping("/course/{courseId}")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByCourse(
            @PathVariable String courseId) {
        return ResponseEntity.ok(ApiResponse.success("Enrollments fetched",
                enrollmentService.getByCourse(courseId)));
    }

    /** PUT /api/enrollments/{id}/drop */
    @PutMapping("/{id}/drop")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> drop(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Enrollment dropped",
                enrollmentService.drop(id)));
    }

    /** PUT /api/enrollments/{id}/complete */
    @PutMapping("/{id}/complete")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> complete(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Enrollment marked as completed",
                enrollmentService.complete(id)));
    }
}
