package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Records daily attendance for a student in a course.
 * Status: PRESENT | ABSENT | LATE
 */
@Document(collection = "attendance")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Attendance {

    @Id
    private String id;

    @Field("studentId")
    private String studentId;

    @Field("studentName")
    private String studentName;

    @Field("courseId")
    private String courseId;

    @Field("courseName")
    private String courseName;

    @Field("date")
    private String date; // format: yyyy-MM-dd

    @Field("status")
    private String status; // PRESENT / ABSENT / LATE

    @Field("markedBy")
    private String markedBy; // facultyId of the marker

    @Field("createdAt")
    private LocalDateTime createdAt;
}
