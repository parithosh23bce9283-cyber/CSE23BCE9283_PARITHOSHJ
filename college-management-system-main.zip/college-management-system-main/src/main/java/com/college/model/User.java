package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Represents an authenticated system user.
 * Roles: ADMIN | FACULTY | STUDENT
 */
@Document(collection = "users")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    private String id;

    @Indexed(unique = true)
    @Field("username")
    private String username;

    @Indexed(unique = true)
    @Field("email")
    private String email;

    @Field("password")
    private String password; // BCrypt hashed

    @Field("role")
    private String role; // ADMIN / FACULTY / STUDENT

    @Field("createdAt")
    private LocalDateTime createdAt;
}
