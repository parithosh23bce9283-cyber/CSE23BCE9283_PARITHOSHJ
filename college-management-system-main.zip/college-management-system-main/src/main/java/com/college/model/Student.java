package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Represents a student enrolled in the college.
 * Roll number is auto-generated: VIT-{year}-{sequence}
 */
@Document(collection = "students")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    private String id;

    @Field("name")
    private String name;

    @Indexed(unique = true)
    @Field("email")
    private String email;

    @Field("phone")
    private String phone;

    @Indexed(unique = true)
    @Field("rollNumber")
    private String rollNumber; // e.g. VIT-2024-0001

    @Field("departmentId")
    private String departmentId;

    @Field("departmentName")
    private String departmentName;

    @Field("semester")
    private int semester; // 1-8

    @Field("batch")
    private String batch; // e.g. "2023-2027"

    @Field("gender")
    private String gender;

    @Field("dateOfBirth")
    private String dateOfBirth;

    @Field("address")
    private String address;

    @Field("isActive")
    private boolean isActive;

    @Field("createdAt")
    private LocalDateTime createdAt;
}
