package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Represents an academic course offered by the college.
 * Tracks enrollment count vs. max capacity.
 */
@Document(collection = "courses")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Course {

    @Id
    private String id;

    @Field("name")
    private String name;

    @Indexed(unique = true)
    @Field("courseCode")
    private String courseCode; // e.g. CS101

    @Field("departmentId")
    private String departmentId;

    @Field("departmentName")
    private String departmentName;

    @Field("facultyId")
    private String facultyId;

    @Field("facultyName")
    private String facultyName;

    @Field("credits")
    private int credits;

    @Field("semester")
    private int semester;

    @Field("maxStudents")
    private int maxStudents;

    @Field("enrolledStudents")
    private int enrolledStudents; // incremented/decremented on enrollment changes

    @Field("createdAt")
    private LocalDateTime createdAt;
}
