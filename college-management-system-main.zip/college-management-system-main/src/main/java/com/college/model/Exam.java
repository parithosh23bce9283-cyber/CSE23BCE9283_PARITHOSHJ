package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Records exam results for a student in a specific course.
 * Grade is auto-calculated based on percentage of obtainedMarks/totalMarks.
 * ExamType: INTERNAL | MIDTERM | FINAL
 */
@Document(collection = "exams")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Exam {

    @Id
    private String id;

    @Field("studentId")
    private String studentId;

    @Field("studentName")
    private String studentName;

    @Field("rollNumber")
    private String rollNumber;

    @Field("courseId")
    private String courseId;

    @Field("courseName")
    private String courseName;

    @Field("courseCode")
    private String courseCode;

    @Field("examType")
    private String examType; // INTERNAL / MIDTERM / FINAL

    @Field("totalMarks")
    private int totalMarks;

    @Field("obtainedMarks")
    private int obtainedMarks;

    @Field("grade")
    private String grade; // auto-calculated: A+, A, B+, B, C, D, F

    @Field("semester")
    private int semester;

    @Field("examDate")
    private String examDate; // format: yyyy-MM-dd

    @Field("createdAt")
    private LocalDateTime createdAt;
}
