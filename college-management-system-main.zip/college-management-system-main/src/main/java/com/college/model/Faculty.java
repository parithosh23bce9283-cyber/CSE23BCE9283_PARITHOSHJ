package com.college.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

/**
 * Represents a faculty member.
 * Employee ID is auto-generated: FAC-{year}-{sequence}
 */
@Document(collection = "faculty")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Faculty {

    @Id
    private String id;

    @Field("name")
    private String name;

    @Indexed(unique = true)
    @Field("email")
    private String email;

    @Field("phone")
    private String phone;

    @Indexed(unique = true)
    @Field("employeeId")
    private String employeeId; // e.g. FAC-2024-001

    @Field("departmentId")
    private String departmentId;

    @Field("departmentName")
    private String departmentName;

    // ASSISTANT_PROFESSOR / ASSOCIATE_PROFESSOR / PROFESSOR
    @Field("designation")
    private String designation;

    @Field("qualification")
    private String qualification;

    @Field("experience")
    private int experience; // years

    @Field("isActive")
    private boolean isActive;

    @Field("createdAt")
    private LocalDateTime createdAt;
}
