package com.college.service;

import com.college.dto.request.AttendanceRequest;
import com.college.dto.response.AttendanceResponse;
import com.college.exception.ResourceNotFoundException;
import com.college.model.Attendance;
import com.college.model.Course;
import com.college.model.Student;
import com.college.repository.AttendanceRepository;
import com.college.repository.CourseRepository;
import com.college.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AttendanceService {

    @Autowired private AttendanceRepository attendanceRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;

    public AttendanceResponse mark(AttendanceRequest request) {
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student", "id", request.getStudentId()));
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course", "id", request.getCourseId()));

        Attendance attendance = Attendance.builder()
                .studentId(student.getId())
                .studentName(student.getName())
                .courseId(course.getId())
                .courseName(course.getName())
                .date(request.getDate())
                .status(request.getStatus())
                .markedBy(request.getMarkedBy())
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(attendanceRepository.save(attendance));
    }

    public List<AttendanceResponse> getByCourse(String courseId) {
        return attendanceRepository.findByCourseId(courseId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<AttendanceResponse> getByStudent(String studentId) {
        return attendanceRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<AttendanceResponse> getByCourseAndDate(String courseId, String date) {
        return attendanceRepository.findByCourseIdAndDate(courseId, date)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Calculate attendance percentage per course for a student.
     * Formula: (PRESENT + LATE) / total × 100
     * Also flags if below 75%.
     */
    public Map<String, Object> getAttendancePercentage(String studentId) {
        List<Attendance> records = attendanceRepository.findByStudentId(studentId);

        // Group by courseId
        Map<String, List<Attendance>> byCourse = records.stream()
                .collect(Collectors.groupingBy(Attendance::getCourseId));

        Map<String, Object> result = byCourse.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> {
                            List<Attendance> courseRecords = entry.getValue();
                            long total = courseRecords.size();
                            long present = courseRecords.stream()
                                    .filter(a -> "PRESENT".equals(a.getStatus())
                                              || "LATE".equals(a.getStatus()))
                                    .count();
                            double percentage = total == 0 ? 0.0 : (double) present / total * 100;
                            String courseName = courseRecords.get(0).getCourseName();
                            boolean belowThreshold = percentage < 75.0;

                            return Map.of(
                                    "courseId", entry.getKey(),
                                    "courseName", courseName,
                                    "totalClasses", total,
                                    "attended", present,
                                    "percentage", Math.round(percentage * 100.0) / 100.0,
                                    "belowMinimum", belowThreshold
                            );
                        }
                ));
        return result;
    }

    private AttendanceResponse toResponse(Attendance a) {
        return AttendanceResponse.builder()
                .id(a.getId())
                .studentId(a.getStudentId())
                .studentName(a.getStudentName())
                .courseId(a.getCourseId())
                .courseName(a.getCourseName())
                .date(a.getDate())
                .status(a.getStatus())
                .markedBy(a.getMarkedBy())
                .createdAt(a.getCreatedAt())
                .build();
    }
}
