package com.college.service;

import com.college.dto.request.ExamRequest;
import com.college.dto.response.ExamResponse;
import com.college.exception.ResourceNotFoundException;
import com.college.exception.ValidationException;
import com.college.model.Course;
import com.college.model.Exam;
import com.college.model.Student;
import com.college.repository.CourseRepository;
import com.college.repository.ExamRepository;
import com.college.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ExamService {

    @Autowired private ExamRepository examRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private CourseRepository courseRepository;

    public ExamResponse addResult(ExamRequest request) {
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student", "id", request.getStudentId()));
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course", "id", request.getCourseId()));

        if (request.getObtainedMarks() > request.getTotalMarks()) {
            throw new ValidationException(
                    "Obtained marks cannot exceed total marks.");
        }

        // Auto-calculate grade based on percentage
        String grade = calculateGrade(request.getObtainedMarks(), request.getTotalMarks());

        Exam exam = Exam.builder()
                .studentId(student.getId())
                .studentName(student.getName())
                .rollNumber(student.getRollNumber())
                .courseId(course.getId())
                .courseName(course.getName())
                .courseCode(course.getCourseCode())
                .examType(request.getExamType())
                .totalMarks(request.getTotalMarks())
                .obtainedMarks(request.getObtainedMarks())
                .grade(grade)
                .semester(request.getSemester())
                .examDate(request.getExamDate())
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(examRepository.save(exam));
    }

    public List<ExamResponse> getByStudent(String studentId) {
        return examRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<ExamResponse> getByCourse(String courseId) {
        return examRepository.findByCourseId(courseId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public ExamResponse update(String id, ExamRequest request) {
        Exam exam = examRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Exam", "id", id));

        if (request.getObtainedMarks() > request.getTotalMarks()) {
            throw new ValidationException("Obtained marks cannot exceed total marks.");
        }

        exam.setTotalMarks(request.getTotalMarks());
        exam.setObtainedMarks(request.getObtainedMarks());
        exam.setGrade(calculateGrade(request.getObtainedMarks(), request.getTotalMarks()));
        exam.setExamType(request.getExamType());
        exam.setExamDate(request.getExamDate());
        exam.setSemester(request.getSemester());

        return toResponse(examRepository.save(exam));
    }

    /**
     * Calculate GPA for a student using all FINAL exam results.
     * GPA = Σ(gradePoint × credits) / Σ(credits)
     * Grade point mapping: A+=10, A=9, B+=8, B=7, C=6, D=5, F=0
     */
    public Map<String, Object> calculateGpa(String studentId) {
        // Use only FINAL exams for GPA (university standard)
        List<Exam> exams = examRepository.findByStudentIdAndExamType(studentId, "FINAL");

        if (exams.isEmpty()) {
            return Map.of(
                    "studentId", studentId,
                    "gpa", 0.0,
                    "message", "No FINAL exam results found for GPA calculation"
            );
        }

        double totalWeightedPoints = 0;
        int totalCredits = 0;

        for (Exam exam : exams) {
            // Fetch course credits for weighting
            int credits = courseRepository.findById(exam.getCourseId())
                    .map(Course::getCredits).orElse(1);
            double gradePoint = gradeToPoint(exam.getGrade());
            totalWeightedPoints += gradePoint * credits;
            totalCredits += credits;
        }

        double gpa = totalCredits == 0 ? 0.0 : totalWeightedPoints / totalCredits;

        return Map.of(
                "studentId", studentId,
                "gpa", Math.round(gpa * 100.0) / 100.0,
                "totalCredits", totalCredits,
                "examsConsidered", exams.size()
        );
    }

    /**
     * Grade auto-calculation based on percentage:
     * 90-100 → A+, 80-89 → A, 70-79 → B+, 60-69 → B,
     * 50-59 → C, 40-49 → D, <40 → F
     */
    private String calculateGrade(int obtained, int total) {
        double pct = (double) obtained / total * 100;
        if (pct >= 90) return "A+";
        if (pct >= 80) return "A";
        if (pct >= 70) return "B+";
        if (pct >= 60) return "B";
        if (pct >= 50) return "C";
        if (pct >= 40) return "D";
        return "F";
    }

    /**
     * Grade point mapping for GPA calculation.
     */
    private double gradeToPoint(String grade) {
        return switch (grade) {
            case "A+" -> 10.0;
            case "A"  -> 9.0;
            case "B+" -> 8.0;
            case "B"  -> 7.0;
            case "C"  -> 6.0;
            case "D"  -> 5.0;
            default   -> 0.0; // F
        };
    }

    private ExamResponse toResponse(Exam e) {
        double pct = (double) e.getObtainedMarks() / e.getTotalMarks() * 100;
        return ExamResponse.builder()
                .id(e.getId())
                .studentId(e.getStudentId())
                .studentName(e.getStudentName())
                .rollNumber(e.getRollNumber())
                .courseId(e.getCourseId())
                .courseName(e.getCourseName())
                .courseCode(e.getCourseCode())
                .examType(e.getExamType())
                .totalMarks(e.getTotalMarks())
                .obtainedMarks(e.getObtainedMarks())
                .grade(e.getGrade())
                .percentage(Math.round(pct * 100.0) / 100.0)
                .semester(e.getSemester())
                .examDate(e.getExamDate())
                .createdAt(e.getCreatedAt())
                .build();
    }
}
