package com.college.service;

import com.college.dto.request.CourseRequest;
import com.college.dto.response.CourseResponse;
import com.college.exception.DuplicateResourceException;
import com.college.exception.ResourceNotFoundException;
import com.college.model.Course;
import com.college.model.Department;
import com.college.model.Faculty;
import com.college.repository.CourseRepository;
import com.college.repository.DepartmentRepository;
import com.college.repository.FacultyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CourseService {

    @Autowired private CourseRepository courseRepository;
    @Autowired private DepartmentRepository departmentRepository;
    @Autowired private FacultyRepository facultyRepository;

    public CourseResponse create(CourseRequest request) {
        if (courseRepository.existsByCourseCode(request.getCourseCode())) {
            throw new DuplicateResourceException("Course", "courseCode", request.getCourseCode());
        }
        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));
        Faculty faculty = facultyRepository.findById(request.getFacultyId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Faculty", "id", request.getFacultyId()));

        Course course = Course.builder()
                .name(request.getName())
                .courseCode(request.getCourseCode().toUpperCase())
                .departmentId(dept.getId())
                .departmentName(dept.getName())
                .facultyId(faculty.getId())
                .facultyName(faculty.getName())
                .credits(request.getCredits())
                .semester(request.getSemester())
                .maxStudents(request.getMaxStudents())
                .enrolledStudents(0) // starts at zero
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(courseRepository.save(course));
    }

    public List<CourseResponse> getAll() {
        return courseRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public CourseResponse getById(String id) {
        return toResponse(findOrThrow(id));
    }

    public List<CourseResponse> getByDepartment(String departmentId) {
        return courseRepository.findByDepartmentId(departmentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<CourseResponse> getByFaculty(String facultyId) {
        return courseRepository.findByFacultyId(facultyId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public CourseResponse update(String id, CourseRequest request) {
        Course course = findOrThrow(id);
        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));
        Faculty faculty = facultyRepository.findById(request.getFacultyId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Faculty", "id", request.getFacultyId()));

        course.setName(request.getName());
        course.setCourseCode(request.getCourseCode().toUpperCase());
        course.setDepartmentId(dept.getId());
        course.setDepartmentName(dept.getName());
        course.setFacultyId(faculty.getId());
        course.setFacultyName(faculty.getName());
        course.setCredits(request.getCredits());
        course.setSemester(request.getSemester());
        course.setMaxStudents(request.getMaxStudents());

        return toResponse(courseRepository.save(course));
    }

    public void delete(String id) {
        courseRepository.delete(findOrThrow(id));
    }

    public Course findOrThrow(String id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course", "id", id));
    }

    private CourseResponse toResponse(Course c) {
        return CourseResponse.builder()
                .id(c.getId())
                .name(c.getName())
                .courseCode(c.getCourseCode())
                .departmentId(c.getDepartmentId())
                .departmentName(c.getDepartmentName())
                .facultyId(c.getFacultyId())
                .facultyName(c.getFacultyName())
                .credits(c.getCredits())
                .semester(c.getSemester())
                .maxStudents(c.getMaxStudents())
                .enrolledStudents(c.getEnrolledStudents())
                .createdAt(c.getCreatedAt())
                .build();
    }
}
