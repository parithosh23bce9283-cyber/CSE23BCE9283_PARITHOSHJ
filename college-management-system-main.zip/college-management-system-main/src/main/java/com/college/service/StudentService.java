package com.college.service;

import com.college.dto.request.StudentRequest;
import com.college.dto.response.StudentResponse;
import com.college.exception.DuplicateResourceException;
import com.college.exception.ResourceNotFoundException;
import com.college.model.Department;
import com.college.model.Student;
import com.college.repository.DepartmentRepository;
import com.college.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.Year;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentService {

    @Autowired private StudentRepository studentRepository;
    @Autowired private DepartmentRepository departmentRepository;

    /**
     * Create a student with auto-generated roll number.
     * Format: VIT-{currentYear}-{4-digit-seq}, e.g. VIT-2024-0001
     */
    public StudentResponse create(StudentRequest request) {
        if (studentRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Student", "email", request.getEmail());
        }

        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));

        String rollNumber = generateRollNumber();
        Student student = Student.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .rollNumber(rollNumber)
                .departmentId(dept.getId())
                .departmentName(dept.getName())
                .semester(request.getSemester())
                .batch(request.getBatch())
                .gender(request.getGender())
                .dateOfBirth(request.getDateOfBirth())
                .address(request.getAddress())
                .isActive(true)
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(studentRepository.save(student));
    }

    /**
     * Auto-generate roll number: VIT-{year}-{4-digit padded count}
     */
    private String generateRollNumber() {
        int year = Year.now().getValue();
        String prefix = "VIT-" + year + "-";
        // Count existing students with the same year prefix to derive the sequence
        long count = studentRepository.countByRollNumberStartingWith(prefix);
        return prefix + String.format("%04d", count + 1);
    }

    public Page<StudentResponse> getAll(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return studentRepository.findAll(pageable).map(this::toResponse);
    }

    public StudentResponse getById(String id) {
        return toResponse(findOrThrow(id));
    }

    public List<StudentResponse> getByDepartment(String departmentId) {
        return studentRepository.findByDepartmentId(departmentId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    /** Case-insensitive search across name and roll number fields */
    public List<StudentResponse> search(String name, String rollNumber) {
        String namePattern = (name != null) ? name : "";
        String rollPattern = (rollNumber != null) ? rollNumber : "";
        return studentRepository.searchByNameOrRollNumber(namePattern, rollPattern)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public StudentResponse update(String id, StudentRequest request) {
        Student student = findOrThrow(id);
        Department dept = departmentRepository.findById(request.getDepartmentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Department", "id", request.getDepartmentId()));

        student.setName(request.getName());
        student.setPhone(request.getPhone());
        student.setDepartmentId(dept.getId());
        student.setDepartmentName(dept.getName());
        student.setSemester(request.getSemester());
        student.setBatch(request.getBatch());
        student.setGender(request.getGender());
        student.setDateOfBirth(request.getDateOfBirth());
        student.setAddress(request.getAddress());

        return toResponse(studentRepository.save(student));
    }

    /** Soft delete — sets isActive to false */
    public void deactivate(String id) {
        Student student = findOrThrow(id);
        student.setActive(false);
        studentRepository.save(student);
    }

    private Student findOrThrow(String id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student", "id", id));
    }

    private StudentResponse toResponse(Student s) {
        return StudentResponse.builder()
                .id(s.getId())
                .name(s.getName())
                .email(s.getEmail())
                .phone(s.getPhone())
                .rollNumber(s.getRollNumber())
                .departmentId(s.getDepartmentId())
                .departmentName(s.getDepartmentName())
                .semester(s.getSemester())
                .batch(s.getBatch())
                .gender(s.getGender())
                .dateOfBirth(s.getDateOfBirth())
                .address(s.getAddress())
                .isActive(s.isActive())
                .createdAt(s.getCreatedAt())
                .build();
    }
}
