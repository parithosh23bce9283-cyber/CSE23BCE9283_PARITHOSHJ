package com.college.service;

import com.college.dto.request.DepartmentRequest;
import com.college.dto.response.DepartmentResponse;
import com.college.exception.DuplicateResourceException;
import com.college.exception.ResourceNotFoundException;
import com.college.model.Department;
import com.college.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public DepartmentResponse create(DepartmentRequest request) {
        if (departmentRepository.existsByName(request.getName())) {
            throw new DuplicateResourceException("Department", "name", request.getName());
        }
        if (departmentRepository.existsByCode(request.getCode())) {
            throw new DuplicateResourceException("Department", "code", request.getCode());
        }

        Department dept = Department.builder()
                .name(request.getName())
                .code(request.getCode().toUpperCase())
                .hodName(request.getHodName())
                .totalSeats(request.getTotalSeats())
                .createdAt(LocalDateTime.now())
                .build();

        return toResponse(departmentRepository.save(dept));
    }

    public List<DepartmentResponse> getAll() {
        return departmentRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public DepartmentResponse getById(String id) {
        return toResponse(findOrThrow(id));
    }

    public DepartmentResponse update(String id, DepartmentRequest request) {
        Department dept = findOrThrow(id);
        dept.setName(request.getName());
        dept.setCode(request.getCode().toUpperCase());
        dept.setHodName(request.getHodName());
        dept.setTotalSeats(request.getTotalSeats());
        return toResponse(departmentRepository.save(dept));
    }

    public void delete(String id) {
        Department dept = findOrThrow(id);
        departmentRepository.delete(dept);
    }

    private Department findOrThrow(String id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department", "id", id));
    }

    private DepartmentResponse toResponse(Department dept) {
        return DepartmentResponse.builder()
                .id(dept.getId())
                .name(dept.getName())
                .code(dept.getCode())
                .hodName(dept.getHodName())
                .totalSeats(dept.getTotalSeats())
                .createdAt(dept.getCreatedAt())
                .build();
    }
}
